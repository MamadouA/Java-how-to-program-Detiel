public class Knight {
    static int moveCounter = 1;
    private int post_x;
    private int post_y;
    private final int[] vertical = { -1, -2, -2, -1, 1, 2, 2, 1 };
    private final int[] horizontal = { 2, 1, -1, -2, -2, -1, 1, 2 };

    public  Knight( int startPost_x, int startPost_y ) {
        this.post_x = startPost_x;
        this.post_y = startPost_y;
    }

   public void moveKnight( int[][] board, int[][] accessibility ) {
        int nextMove;
        nextMove = findMove( board, accessibility );
        if( nextMove != -1 ) {
            --accessibility[ post_x ][ post_y ];
            post_x += horizontal[ nextMove ];
            post_y += vertical[ nextMove ];
            board[ post_x ][ post_y ] = ++moveCounter;
        }
    } // end function moveKnight

    private int findMove( int[][] board, int[][] accessibility ) {
        final int MOVE_TYPES = 8;
        int nextMove = -1;
        int nextPost_x;
        int nextPost_y;
        int lowestAccessibilityNum = 100;

        for( int move = 0; move < MOVE_TYPES; ++move ) {
            nextPost_x = post_x + horizontal[ move ];
            nextPost_y = post_y + vertical[ move ];

            if( isInsideArray( board[ 0 ].length, nextPost_x, nextPost_y ) ) {
                if( board[ nextPost_x ][ nextPost_y ] == 0 ) {
                    if( accessibility[ nextPost_x ][ nextPost_y ] < lowestAccessibilityNum ) {
                        nextMove = move;
                        lowestAccessibilityNum = accessibility[ nextPost_x ][ nextPost_y ];
                    }
                    /*else if( accessibility[ nextPost_x ][ nextPost_y ] == lowestAccessibilityNum ) {

                    }*/
                }
            }
        }
        return nextMove;
    } // end function findMove
    private boolean isInsideArray( int arrayLength, int row, int column ) {
        return  ( row >= 0 && row < arrayLength ) && ( column >= 0 && column < arrayLength );
    } // end function isInsideArray
} // end class knight


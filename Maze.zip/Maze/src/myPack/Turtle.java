package myPack;

public class Turtle {
    // hold the current position of the maze
    private int current_row;
    private int current_column;

    // Turtle constructor
    public Turtle( int entry_row, int entry_column ) {
        this.current_row = entry_row;
        this.current_column = entry_column;
    }

    // traverse method
    public void traverse( char[][] maze, int entry_row,
                          int entry_column, int exit_row, int exit_column ) {

        maze[ current_row ][ current_column ] = 'x'; // initialize the starting square

        do{
            if( !found_exit( maze, exit_row, exit_column ) ) {
                maze[ current_row ][ current_column ] = ' '; // remove 'x'
                MazeTraverse.showMaze( maze ); // print the maze
                System.out.println(); // new line
                find_path( maze, 'x' ); // move one square backward
            }
        }while( ( ( current_row != entry_row ) || ( current_column != entry_column ) ) &&
                ( ( current_row != exit_row ) || ( current_column != exit_column ) ) );
    }

    // find the next square to move the turtle
    private boolean find_path( char[][] maze, char path ) {

        // can the turtle move to the next column (forward)
        if( current_column + 1 < maze[ current_row ].length &&
                    maze[ current_row ][ current_column + 1 ] == path ) {
            ++current_column;
        }
        // can the turtle move to the next row (downward)
        else if( current_row + 1 < maze.length &&
                maze[ current_row + 1 ][ current_column ] == path ) {
            ++current_row;
        }
        // can the turtle move to the next row (upward)
        else if( current_row - 1 >= 0 &&
                    maze[ current_row - 1 ][ current_column ] == path ) {
            --current_row;
        }
        // can the turtle move to the next column (backward)
        else if( current_column - 1 >= 0 &&
                    maze[ current_row ][ current_column - 1 ] == path ) {
            --current_column;
        }
        else {
            return false; // no move possible
        }
        return true; // moved successfully
    }
    // try to find the exit
    private boolean found_exit(char[][] maze, int exit_row, int exit_column ) {
        while( find_path( maze, '.') ) {
            maze[ current_row ][ current_column ] = 'x'; // make a move

            MazeTraverse.showMaze( maze ); // print the maze
            System.out.println(); // new line

            // if the exit is found
            if( current_row == exit_row && current_column == exit_column ) {
                return true;
            }
        }
        return false;
    }
}

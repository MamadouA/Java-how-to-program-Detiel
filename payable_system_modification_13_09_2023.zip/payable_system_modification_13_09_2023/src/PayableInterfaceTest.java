// Fig. 10.15: PayableInterfaceTest.java
// Payable interface test program processing Invoices and
// Employee polymorphically
public class PayableInterfaceTest {
    public static void main( String[] args ) {
        // create four-element Payable array
        Payable[] payableObjects = new Payable[ 6 ];

        // populate array with objects that implements Payable
        payableObjects[ 0 ] = new Invoice( "01234", "seat", 2, 375.00 );
        payableObjects[ 1 ] = new Invoice( "56789", "titre", 4, 79.75 );
        payableObjects[ 2 ] =
                new SalariedEmployee( "John", "Smith", "111-11-1111", 800.00 );
        payableObjects[ 3 ] =
                new CommissionEmployee( "Modou", "Ndiaye",
                        "111-11-1111", 300.2, 0.5 );
        payableObjects[ 4 ] =
                new HourlyEmployee( "Abdoulaye", "Mbaye", "222-22-222", 25.0, 12 );
        payableObjects[ 5 ] =
                new BasePlusCommissionEmployee( "Samba", "Mbacke",
                        "333-33-333", 400.0, 0.3, 500.0 );

        System.out.println( "Invoices and Employees processed polymorphically: " );

        // generally process each element in array payableObjects
        for( Payable currentPayable : payableObjects ) {
            // output currentPayable and its appropriate payment amount
            System.out.printf( "%n%s %n",
                    // could invoke implicitly
                    currentPayable.toString() );

            if( currentPayable instanceof BasePlusCommissionEmployee ) {
                BasePlusCommissionEmployee employee = ( BasePlusCommissionEmployee ) currentPayable;
                employee.setBaseSalary( employee.getBaseSalary() * 1.1 );
            }
            System.out.printf( "%s: $%,.2f%n", "payment due", currentPayable.getPaymentAmount() );
        }
    } // end main
} // end class PayableInterfaceTest

// TypingApp class
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class TypingApp extends JFrame
{
    private final VirtualKeyboard virtualKeyboard;
    private final JTextArea textArea;
    private final Color buttonDefaultColor;

    // constructor
    public TypingApp()
    {
        super("Typing Application");
        setLayout(null);

        // initialize buttonDefaultColor
        buttonDefaultColor = new JButton("").getBackground();

        // create labelsPanel which is the top panel
        JPanel labelsPanel = new JPanel();
        labelsPanel.setLayout(new BorderLayout());

        // add labels to labelPanel
        labelsPanel.add(new JLabel("Type some text using your keyboard. " +
                        " The key you press will be highlighted and the text will be displayed."),
                BorderLayout.NORTH);
        labelsPanel.add(new JLabel("Note: Clicking the buttons with your mouse will not" +
                " perform any action."), BorderLayout.SOUTH);

        // position labelsPanel
        labelsPanel.setBounds(20, 5, 640, 35);

        // add labelsPanel to the app
        add(labelsPanel);

        // initialize textArea
        textArea = new JTextArea();
        textArea.setLineWrap(true);

        // position textArea
        textArea.setBounds(10, 45, 620, 150);
        add(textArea); // add textArea

        // create a virtualKeyboard
        virtualKeyboard = new VirtualKeyboard();
        virtualKeyboard.setBounds(10, 205, 640, 200);

        // add virtualKeyboard to the app
        add(virtualKeyboard);

        // create an event handler for textArea
        TextAreaEventHandler textAreaEventHandler = new TextAreaEventHandler();

        // register textAreaEventHandler for textArea events
        textArea.addKeyListener(textAreaEventHandler);
    } // end constructor

    // private class TextAreaEventHandler
    // this class handle the event of textArea
    private class TextAreaEventHandler extends KeyAdapter
    {
        @Override
        public void keyPressed(KeyEvent e)
        {
            virtualKeyboard.changeButtonColor(KeyEvent.getKeyText(e.getKeyCode()), Color.RED);
        }

        @Override
        public void keyReleased(KeyEvent e)
        {
            virtualKeyboard.changeButtonColor(KeyEvent.getKeyText(e.getKeyCode()), buttonDefaultColor);
        }
    } // end inner class

    public static void main(String[] args)
    {
        try // setup nimbus look and feel
        {
            for(UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
            {
                if("Nimbus".equals(info.getName()))
                {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        catch (Exception e) { // empty catch block
        } // end catch block

        TypingApp typingApp = new TypingApp();
        typingApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        typingApp.setSize(660, 450);
        typingApp.setVisible(true);
        typingApp.setResizable(false);
    } // end main
}

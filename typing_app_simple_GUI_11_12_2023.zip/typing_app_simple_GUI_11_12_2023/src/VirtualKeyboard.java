// this class extends JPanel
// and represent a keyboard
import javax.swing.*;
import java.awt.*;

public class VirtualKeyboard extends JPanel
{
    private final String[] line_1 = {"~", "1", "2", "3", "4", "5", "6", "7",
                                     "8", "9", "0", "-", "+"};
    private final String[] line_2 = {"Q", "W", "E", "R", "T", "y",
                                     "U", "I", "O", "P", "[", "]", "\\"};
    private final String[] line_3 = {"A", "S", "D", "F", "G", "H",
                                       "J", "K", "L", ";", "\""};
    private final String[] line_4 = {"Z", "X", "C", "V", "B",
                                       "N", "M", ",", ".", "?"};

    private final JButton[] buttons;
    private int buttonsCounter = 0; // counter for buttons
    private final int buttonDefaultWidth = 40;
    private final int buttonDefaultHeight = 40;

    // constructor
    public VirtualKeyboard()
    {
        setLayout(null);

        // initialize buttons[]
        buttons = new JButton[57];

        // create the first line's buttons with the same width and height
        for(int counter = 0; counter < line_1.length; ++counter)
        {
            // add buttons to the array buttons
            buttons[buttonsCounter] = new JButton(line_1[counter]);

            // set the position of the buttons
            buttons[buttonsCounter].setBounds(counter * buttonDefaultWidth, 0,
                                buttonDefaultWidth, buttonDefaultHeight);

            // add each button to VirtualKeyboard
            add(buttons[buttonsCounter]);

            // increment the number of button created
            ++buttonsCounter;
        } // end for

        // create, position and add backspace button
        buttons[buttonsCounter] = new JButton("Backspace");
        buttons[buttonsCounter].setBounds(line_1.length * buttonDefaultWidth, 0,
                buttonDefaultWidth + 60 , buttonDefaultHeight);
        add(buttons[buttonsCounter]);

        // create and add tab button in line 2
        buttons[++buttonsCounter] = new JButton("Tab");
        buttons[buttonsCounter].setBounds(0, buttonDefaultHeight, buttonDefaultWidth + 20,
                            buttonDefaultHeight);
        add(buttons[buttonsCounter]);

        // create the second line's panel
        // contain the remaining buttons of line 2
        JPanel line2Panel = new JPanel(null);

        for(int counter = 0; counter < line_2.length; ++counter)
        {
            // next empty array spot
            ++buttonsCounter;

            // create, position and add buttons
            buttons[buttonsCounter] = new JButton(line_2[counter]);
            buttons[buttonsCounter].setBounds(counter * buttonDefaultWidth,
                    0, buttonDefaultWidth, buttonDefaultHeight);
            line2Panel.add(buttons[buttonsCounter]);
        } // end for

        // add line2Panel to VirtualKeyboard
        line2Panel.setBounds(buttonDefaultWidth + 20, buttonDefaultHeight,
                line_2.length * buttonDefaultWidth, buttonDefaultHeight);
        add(line2Panel);

        // create caps button in line 3
        buttons[++buttonsCounter] = new JButton("Caps");
        buttons[buttonsCounter].setBounds(0, buttonDefaultHeight * 2,
                                buttonDefaultWidth + 20, buttonDefaultHeight);
       add(buttons[buttonsCounter]);

       // create the panel of line 3
        JPanel line3Panel = new JPanel(null);

        // add buttons with the same width and height to line3Panel
        for(int counter = 0; counter < line_3.length; ++counter)
        {
            // next unoccupied spot of array buttons
            ++buttonsCounter;

            // create button
            buttons[buttonsCounter] = new JButton(line_3[counter]);

            // add and position each buttons
            buttons[buttonsCounter].setBounds(counter * buttonDefaultWidth, 0,
                    buttonDefaultWidth, buttonDefaultHeight);

            line3Panel.add(buttons[buttonsCounter]);
        } // end for

        // add and position line3Panel
        line3Panel.setBounds(buttonDefaultWidth + 20, buttonDefaultHeight * 2,
                         buttonDefaultWidth * line_3.length, buttonDefaultHeight);
        add(line3Panel);

        // create, position and add enter button
        buttons[++buttonsCounter] = new JButton("Enter");
        buttons[buttonsCounter].setBounds(buttonDefaultWidth + 20 + buttonDefaultWidth * line_3.length,
                buttonDefaultHeight * 2, buttonDefaultWidth + 40, buttonDefaultHeight);
        add(buttons[buttonsCounter]);

        // create position and add the shift button
        buttons[++buttonsCounter] = new JButton("Shift");
        buttons[buttonsCounter].setBounds(0, buttonDefaultHeight * 3,
                        buttonDefaultWidth + 40, buttonDefaultHeight);
        add(buttons[buttonsCounter]);

        // create and position the fourth line's panel
        JPanel line4Panel = new JPanel(null);

        // create, add buttons to line4Panel
        for(int counter = 0; counter < line_4.length; ++counter)
        {
            // unoccupied spot of buttons array
            ++buttonsCounter;

            // create and position each buttons
            buttons[buttonsCounter] = new JButton(line_4[counter]);
            buttons[buttonsCounter].setBounds(counter * buttonDefaultWidth, 0,
                    buttonDefaultWidth, buttonDefaultHeight);

            line4Panel.add(buttons[buttonsCounter]);
        } // end for

        // position and add line4Panel
        line4Panel.setBounds(buttonDefaultWidth + 40, buttonDefaultHeight * 3,
                buttonDefaultWidth * line_4.length, buttonDefaultHeight);
        add(line4Panel);

        // create and position the upper arrow button
        buttons[++buttonsCounter] = new JButton("˄");
        buttons[buttonsCounter].setBounds(buttonDefaultWidth + 60 + buttonDefaultWidth * line_4.length,
                buttonDefaultHeight * 3, buttonDefaultWidth, buttonDefaultHeight);
        add(buttons[buttonsCounter]);

        // create and position the space button
        buttons[++buttonsCounter] = new JButton("");
        buttons[buttonsCounter].setBounds(160, buttonDefaultHeight * 4, buttonDefaultWidth * 6,
                            buttonDefaultHeight);
        add(buttons[buttonsCounter]);


        // create and position left arrow button
        buttons[++buttonsCounter] = new JButton("˂");
        buttons[buttonsCounter].setBounds(460, buttonDefaultHeight * 4, buttonDefaultWidth,
                            buttonDefaultHeight);
        add(buttons[buttonsCounter]);

        // create and position bottom arrow button
        buttons[++buttonsCounter] = new JButton("˅");
        buttons[buttonsCounter].setBounds(460 + buttonDefaultWidth, buttonDefaultHeight * 4,
                    buttonDefaultWidth, buttonDefaultHeight);
        add(buttons[buttonsCounter]);

        // create and position right arrow button
        buttons[++buttonsCounter] = new JButton("˅");
        buttons[buttonsCounter].setBounds(460 + 2 * buttonDefaultWidth, buttonDefaultHeight * 4,
                buttonDefaultWidth, buttonDefaultHeight);
        add(buttons[buttonsCounter]);
    } // end constructor


    // change a button's color
    public void changeButtonColor(String text, Color color)
    {
        JButton currentButton = null;

        // search the pressed button based on it's text
        for(JButton button : buttons)
        {
            if(button.getText().equals(text))
            {
                currentButton = button;
                break;
            }
        } // end for

        // search the pressed button based on its actual name
        if(currentButton == null)
        {
            switch(text)
            {
                case "Back Quote" -> currentButton = buttons[0];
                case "Minus" -> currentButton = buttons[11];
                case "Equals" -> currentButton = buttons[12];
                case "Open Bracket" -> currentButton = buttons[25];
                case "Close Bracket" -> currentButton = buttons[26];
                case "Back Slash" -> currentButton = buttons[27];
                case "Caps Lock" -> currentButton = buttons[28];
                case "Semicolon" -> currentButton = buttons[38];
                case "Quote" -> currentButton = buttons[39];
                case "Comma" -> currentButton = buttons[49];
                case "Period" -> currentButton = buttons[50];
                case "Slash" -> currentButton = buttons[51];
                case "Up" -> currentButton = buttons[52];
                case "Space" -> currentButton = buttons[53];
                case "Left" -> currentButton = buttons[54];
                case "Down" -> currentButton = buttons[55];
                case "Right" -> currentButton = buttons[56];
            }
        } // end for

        if(currentButton != null)
            currentButton.setBackground(color);
    } // end function changeButtonColor
}


public class KnightTest {
    static final int BOARD_SIZE = 8;

    public static void main( String[] args ) {
        int[][] chessboard = new int[ BOARD_SIZE ][ BOARD_SIZE ];
        Knight myKnight = new Knight( 0, 0 );
        int[][] accessibility = { { 2, 3, 4, 4, 4, 4, 3, 2 },
                                  { 3, 4, 6, 6, 6, 6, 4, 2 },
                                  { 4, 6, 8, 8, 8, 8, 6, 4 },
                                  { 4, 6, 8, 8, 8, 8, 6, 4 },
                                  { 4, 6, 8, 8, 8, 8, 6, 4 },
                                  { 4, 6, 8, 8, 8, 8, 6, 4 },
                                  { 3, 4, 6, 6, 6, 8, 4, 2 },
                                  { 2, 3, 4, 4, 4, 4, 3, 2 } };

        chessboard[ 0 ][ 0 ] = 1; // initialize the start position
        for( int squares = 0; squares < 64; ++squares ) {
            myKnight.moveKnight( chessboard, accessibility );
        }

        show2DArray( chessboard );
    }

    public static void show2DArray( int[][] myArray ) {
        for( int i = 0; i < myArray[ 0 ].length; ++i ) {
            for( int j : myArray[ i ] ) {
                System.out.printf( "%4d", j );
            }
            System.out.println();
        }
    }
}

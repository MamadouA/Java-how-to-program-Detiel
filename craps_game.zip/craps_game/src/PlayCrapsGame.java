import javax.swing.UIManager;
import javax.swing.JFrame;

public class PlayCrapsGame
{
    public static void main(String[] args)
    {
        try // setup nimbus look and feel
        {
            for(UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
            {
                if("Nimbus".equals(info.getName()))
                {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        catch (Exception e) { // empty catch block
        } // end catch block

        CrapsGame crapsGame = new CrapsGame();
        crapsGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        crapsGame.setSize(380, 200);
        crapsGame.setVisible(true);
    } // end main
}

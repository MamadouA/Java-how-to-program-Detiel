package myPack;

public class MazeTraverse {
    public static void main( String[] args ) {
        char[][] maze = { { '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#' },
                          { '#', '.', '.', '.', '#', '.', '.', '.', '.', '.', '.', '#' },
                          { '.', '.', '#', '.', '#', '.', '#', '#', '#', '#', '.', '#' },
                          { '#', '#', '#', '.', '#', '.', '.', '.', '.', '#', '.', '#' },
                          { '#', '.', '.', '.', '.', '#', '#', '#', '.', '#', '.', '.' },
                          { '#', '#', '#', '#', '.', '#', '.', '#', '.', '#', '.', '#' },
                          { '#', '.', '.', '#', '.', '#', '.', '#', '.', '#', '.', '#' },
                          { '#', '#', '.', '#', '.', '#', '.', '#', '.', '#', '.', '#' },
                          { '#', '.', '.', '.', '.', '.', '.', '.', '.', '#', '.', '#' },
                          { '#', '#', '#', '#', '#', '#', '.', '#', '#', '#', '.', '#' },
                          { '#', '.', '.', '.', '.', '.', '.', '#', '.', '.', '.', '#' },
                          { '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#' } };

        final int entry_row = 2;
        final int entry_column = 0;

        final int exit_row = 4;
        final int exit_column = 11;

        Turtle turtle = new Turtle( entry_row, entry_column );
        turtle.traverse( maze, entry_row, entry_column, exit_row, exit_column );
    }

    public static void showMaze( char[][] maze ) {
        for( char[] a : maze ) {
            for( char value : a ) {
                System.out.printf( "%3c", value );
            }
            System.out.println();
        }
    }
}

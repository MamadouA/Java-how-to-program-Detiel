// draw a series of 8 concentric circles
// separated by 10 pixels
import javax.swing.JPanel;
import java.awt.Graphics;

public class ConcentricCirclePanel extends JPanel
{
    @Override
    public void paintComponent(Graphics g)
    {
        // call method paintComponent of the superclass
        super.paintComponent(g);

        for(int counter = 0; counter < 80; counter += 10)
        {
            g.drawArc(160 - counter, 150 - counter,
                    30 + 2 * counter, 30 + 2 * counter, 0, 360);
        }
    }
}

import javax.swing.UIManager;
import javax.swing.JFrame;

public class DisplayEventsTest
{
    public static void main(String[] args)
    {
        try // setup nimbus look and feel
        {
            for(UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
            {
                if("Nimbus".equals(info.getName()))
                {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        catch (Exception e) { // empty catch block
        } // end catch block

        DisplayEvents displayEvents = new DisplayEvents();
        displayEvents.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        displayEvents.setSize(500, 500);
        displayEvents.setVisible(true);
    } // end main
}

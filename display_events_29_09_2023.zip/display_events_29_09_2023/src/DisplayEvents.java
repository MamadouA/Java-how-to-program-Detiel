import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class DisplayEvents extends JFrame
{
    private final JTextField textField;
    private final JLabel actionListenerEvent;
    private final JCheckBox checkBox1;
    private final JCheckBox checkBox2;
    private final JLabel itemListenerEvent;
    private final JList<String> list;
    private final String[] listArray = {"RED", "BLUE", "GREEN", "BLACK", "GRAY", "YELLOW", "MAGENTA"};
    private final JLabel listSelectionListenerEvent;
    private final JButton mouseListenerButton;
    private final JLabel mouseListenerEvent;
    private final JLabel mouseMotionListenerLabel;
    private final JLabel mouseMotionListenerEvent;
    private final JTextArea textArea;
    private final JLabel keyboardEvent;

   // constructor
    public DisplayEvents()
    {
        super("Display events");
        setLayout(new GridLayout(18, 1));

        add(new JLabel("Enter something to display an ActionListener event: "));

        // initialize and add textField to the app
        textField = new JTextField(10);
        add(textField);

        // initialize and add actionListenerEvent
        actionListenerEvent = new JLabel();
        add(actionListenerEvent);

        add(new JLabel("Select a value to display a ListSelectionListener event"));

        // initialize and add JList to the app
        list = new JList<>(listArray);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setVisibleRowCount(5);
        add(new JScrollPane(list));

        // initialize and add listSelectionListenerEvent
        listSelectionListenerEvent = new JLabel();
        add(listSelectionListenerEvent);

        add(new JLabel("Select a value to display an ItemListener event"));

        // initialize and add two checkboxes
        checkBox1 = new JCheckBox("checkbox1");
        checkBox2 = new JCheckBox("checkbox2");
        add(checkBox1);
        add(checkBox2);

        // initialize and add itemListenerEvent
        itemListenerEvent = new JLabel();
        add(itemListenerEvent);

        add(new JLabel("Click the button to display a MouseListener event"));

        // initialize and add a JButton
        mouseListenerButton = new JButton("Click me");
        add(mouseListenerButton);

        // initialize and add mouseListenerEvent
        mouseListenerEvent = new JLabel();
        add(mouseListenerEvent);

        // initialize and add a JLabel
        mouseMotionListenerLabel = new JLabel("Move the mouse over me to display a MouseMotionListener event");
        add(mouseMotionListenerLabel);

        // initialize and add mouseMotionListenerEvent
        mouseMotionListenerEvent = new JLabel();
        add(mouseMotionListenerEvent);

        add(new JLabel("Enter something to display a keyListener event"));

        // initialize and add a JTextArea
        textArea = new JTextArea();
        add(textArea);

        // initialize and add keyboardEvent
        keyboardEvent = new JLabel();
        add(keyboardEvent);

        // register an event handler for textField
        textField.addActionListener(new ActionListenerHandler());

        // register an event handler for list
        list.addListSelectionListener(new ListSelectionListenerHandler());

        // register an event handler for the checkBoxes
        checkBox1.addItemListener(new ItemListenerHandler());
        checkBox2.addItemListener(new ItemListenerHandler());

        // register an event handler for mouseListenerButton
        mouseListenerButton.addMouseListener(new MouseListenerHandler());

        // register an event handler for mouseMotionListenerEvent
        mouseMotionListenerLabel.addMouseMotionListener(new MouseMotionListenerHandler());

        // register an event handler for textArea
        textArea.addKeyListener(new KeyboardListenerHandler());
    }

    // inner class for ActionEvent
    private class ActionListenerHandler implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            actionListenerEvent.setText(toString(e));
        }

        // Sting representation of the event
        public String toString(ActionEvent e)
        {
            return String.format("You entered %s in the text field", e.getActionCommand());
        }
    }

    // inner class for ListSelectionListener
    private class ListSelectionListenerHandler implements ListSelectionListener
    {
        @Override
        public void valueChanged(ListSelectionEvent e)
        {
            listSelectionListenerEvent.setText(toString());
        }

        // String representation of the event
        @Override
        public String toString()
        {
            return String.format("You selected %s form the list", list.getSelectedValue());
        }
    }

    private class ItemListenerHandler implements ItemListener
    {
        @Override
        public void itemStateChanged(ItemEvent e)
        {
            if(checkBox1.isSelected() && checkBox2.isSelected())
            {
                itemListenerEvent.setText(toString("all the checkboxes"));
            }
            else if(checkBox1.isSelected())
            {
                itemListenerEvent.setText(toString("checkbox1"));
            }
            else if(checkBox2.isSelected())
            {
                itemListenerEvent.setText(toString("checkbox2"));
            }
            else
                itemListenerEvent.setText("");
        }

        // String representation of the event
        public String toString(String selectedBox)
        {
            return String.format("You selected %s", selectedBox);
        }
    }

    private class MouseListenerHandler implements MouseListener
    {

        @Override
        public void mouseClicked(MouseEvent e)
        {
            mouseListenerEvent.setText(toString("mouseClicked", e));
        }

        @Override
        public void mousePressed(MouseEvent e)
        {
            mouseListenerEvent.setText(toString("mousePressed", e));
        }

        @Override
        public void mouseReleased(MouseEvent e)
        {
            mouseListenerEvent.setText(toString("mouseReleased", e));
        }

        @Override
        public void mouseEntered(MouseEvent e)
        {
            mouseListenerEvent.setText(toString("mouseEntered", e));
        }

        @Override
        public void mouseExited(MouseEvent e)
        {
            mouseListenerEvent.setText(toString("mouseExited", e));
        }

        // String representation of the event
        public String toString(String method, MouseEvent e)
        {
            return String.format("From method: %s  Mouse position: [%d %d]",
                    method, e.getX(), e.getY());
        }
    }

    private class MouseMotionListenerHandler implements MouseMotionListener
    {

        @Override
        public void mouseDragged(MouseEvent e)
        {
            mouseMotionListenerEvent.setText(toString("mouseDragged", e));
        }

        @Override
        public void mouseMoved(MouseEvent e)
        {
            mouseMotionListenerEvent.setText(toString("mouseMoved", e));
        }

        // String representation of the event
        public String toString(String method, MouseEvent e)
        {
            return String.format("From method: %s  Mouse positioned at [%d, %d]",
                    method, e.getX(), e.getY());
        }
    }

    private class KeyboardListenerHandler implements KeyListener
    {

        @Override
        public void keyTyped(KeyEvent e)
        {
           toString("keyTyped", String.format("key typed: %c", e.getKeyChar()));
        }

        @Override
        public void keyPressed(KeyEvent e)
        {
            String key = KeyEvent.getModifiersExText(e.getModifiersEx());

            keyboardEvent.setText( key.equals("") ?
                    toString("keyPressed", KeyEvent.getKeyText(e.getKeyCode())) :
                        toString("keyPressed", key));
        }

        @Override
        public void keyReleased(KeyEvent e)
        {
            String key = KeyEvent.getModifiersExText(e.getModifiersEx());

            keyboardEvent.setText( key.equals("") ?
                    toString("keyReleased", KeyEvent.getKeyText(e.getKeyCode())) :
                    toString("keyReleased", key));
        }

        // String representation of the event
        public String toString(String method, String keyText)
        {
            return String.format("From method %s  key: %s", method, keyText);
        }
    }
} // end DisplayEvents

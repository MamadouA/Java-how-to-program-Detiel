import javax.swing.*;

public class ConverterTest
{
    public static void main(String[] args)
    {
        try // setup nimbus look and feel
        {
            for(UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
            {
                if("Nimbus".equals(info.getName()))
                {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        catch (Exception e) { // empty catch block
        } // end try-statement

        // create a Converter object
        Converter converter = new Converter();
        converter.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        converter.setSize(300, 150);
        converter.setVisible(true);
    }
}

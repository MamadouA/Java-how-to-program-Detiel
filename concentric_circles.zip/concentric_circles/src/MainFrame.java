import javax.swing.JFrame;

public class MainFrame
{
    public static void main(String[] args)
    {
        JFrame concentricCircleFrame = new JFrame("Concentric Circles");

        concentricCircleFrame.add(new ConcentricCirclePanel());

        concentricCircleFrame.setVisible(true);
        concentricCircleFrame.setSize(400, 400);
        concentricCircleFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Converter extends JFrame
{
    private final JTextField fahrenheitTemperature;
    private final JLabel celsiusTemperature;
    private double celsius;
    private double fahrenheit;

    public Converter()
    {
        // app's title
        super("Fahrenheit to celsius");
        setLayout(new GridLayout(3, 1));

        // prompt the user
        add(new JLabel("Enter the temperature in Fahrenheit: "));

        // text field
        fahrenheitTemperature = new JTextField();
        fahrenheitTemperature.addActionListener(
                new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            fahrenheit = Double.parseDouble(e.getActionCommand());
                            celsius = 5.0 / 9 * (fahrenheit - 32 );
                            celsiusTemperature.setText(String.format("%s%.2fF", "Temperature in celsius: ", celsius));
                        }
                        catch(NumberFormatException ex)
                        {
                            celsiusTemperature.setText(String.format("Please enter a correct value!"));
                        }
                    }
                }
        );
        // add fahrenheitTemperature to Converter.
        add(fahrenheitTemperature);

        // output label
        celsiusTemperature = new JLabel("", SwingConstants.CENTER);
        add(celsiusTemperature);
    }
}

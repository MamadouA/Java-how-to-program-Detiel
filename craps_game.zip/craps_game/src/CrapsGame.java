import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.security.SecureRandom;

public class CrapsGame extends JFrame
{
    // create secure random number generator for use in method rollDice
    private static final SecureRandom randomNumbers = new SecureRandom();
    private final JPanel board;
    private final JLabel firstDiceLabel;
    private final JLabel secondDiceLabel;
    private final JLabel scoreLabel;
    private final JLabel sumOfTheDiceLabel;
    private final JLabel gameStatus;
    private final JTextField firstDiceField;
    private final JTextField secondDiceField;
    private final JTextField scoreField;
    private final JTextField sumOfDiceField;
    private final JButton rollButton;

    public CrapsGame()
    {
        // name and layout of the app
        super("Craps Game");
        setLayout(new BorderLayout());

        // contains the game statistics
        board = new JPanel();
        board.setLayout(new GridLayout(4, 2, 4, 2));

        // initialize and components to board
        firstDiceLabel = new JLabel("First Dice");
        firstDiceLabel.setHorizontalAlignment(JLabel.CENTER);
        board.add(firstDiceLabel);

        secondDiceLabel = new JLabel("Second Dice");
        secondDiceLabel.setHorizontalAlignment(JLabel.CENTER);
        board.add(secondDiceLabel);

        firstDiceField = new JTextField();
        board.add(firstDiceField);

        secondDiceField = new JTextField();
        board.add(secondDiceField);

        sumOfTheDiceLabel = new JLabel("Sum of the Dice");
        sumOfTheDiceLabel.setHorizontalAlignment(JLabel.CENTER);
        board.add(sumOfTheDiceLabel);

        scoreLabel = new JLabel("Score");
        scoreLabel.setHorizontalAlignment(JLabel.CENTER);
        board.add(scoreLabel);

        sumOfDiceField = new JTextField();
        board.add(sumOfDiceField);

        scoreField = new JTextField();
        board.add(scoreField);

        // add board to the frame
        add(board, BorderLayout.NORTH);

        rollButton = new JButton("Roll Dice");
        add(rollButton, BorderLayout.CENTER);

        // create a RollDiceHandler object
        RollDiceHandler rollHandler = new RollDiceHandler();

        // register an event handler
        rollButton.addActionListener(rollHandler);

        gameStatus = new JLabel(" ");
        gameStatus.setHorizontalAlignment(JLabel.CENTER);
        add(gameStatus, BorderLayout.SOUTH);
    } // end constructor


    // event handler for rollButton
    private class RollDiceHandler implements ActionListener
    {
        // enum type with constants that represent the game status
        private enum Status {CONTINUE, WON, LOST};

        // constants that represent common rolls of the dice
        private static final int SNAKE_EYES = 2;
        private static final int TREY = 3;
        private static final int SEVEN = 7;
        private static final int YO_LEVEN = 11;
        private static final int BOX_CARDS = 12;

        private int myPoint = 0; // point if no win or lost on first roll
        private Status gameStatus; // can contain WIN, LOST or CONTINUE
        private int sumOfDice = 0;

        @Override
        public void actionPerformed(ActionEvent e)
        {
            sumOfDice = rollDice(CrapsGame.this); // first roll of the dice
            CrapsGame.this.gameStatus.setText(" ");

            if(gameStatus == Status.CONTINUE)
            {
                // determine game status
                if(sumOfDice == myPoint) // win by making point
                    gameStatus = Status.WON;
                else
                if(sumOfDice == SEVEN) // lose by rolling 7 before point
                    gameStatus = Status.LOST;
            }
            else {
                switch (sumOfDice) {
                    case SEVEN: // win with 7 on first roll
                    case YO_LEVEN: // win with 11 on first roll
                        gameStatus = Status.WON;
                        break;
                    case SNAKE_EYES: // lose with 2 on first roll
                    case TREY: // lose with 3 on first roll
                    case BOX_CARDS: // lose with 12 on first roll
                        gameStatus = Status.LOST;
                        break;
                    default: // did no win or lose, so remember point
                        gameStatus = Status.CONTINUE; // game is not over
                        myPoint = sumOfDice; // remember the point
                        scoreField.setText(Integer.toString(myPoint));
                } // end switch
            } // end else

            // display won or lost message
            if(gameStatus == Status.WON)
                CrapsGame.this.gameStatus.setText("YOU WON");
            else if(gameStatus == Status.LOST)
                CrapsGame.this.gameStatus.setText("YOU LOST");
        }

        // roll dice, calculate sum and display results
        private static int rollDice(CrapsGame crapsGame)
        {
            // pick random die values
            int die1 = 1 + randomNumbers.nextInt(6);
            int die2 = 1 + randomNumbers.nextInt(6);
            int sum = die1 + die2;

            // display the results on the window
            crapsGame.firstDiceField.setText(Integer.toString(die1));
            crapsGame.secondDiceField.setText(Integer.toString(die2));
            crapsGame.sumOfDiceField.setText(Integer.toString(sum));

            return sum; // return the sum
        }
    } // end inner class
    // roll dice, calculate sum and display results
}
